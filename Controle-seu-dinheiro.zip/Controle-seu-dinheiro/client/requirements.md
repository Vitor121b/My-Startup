## Packages
framer-motion | Animations for page transitions and micro-interactions
recharts | Charts for financial dashboard
date-fns | Date formatting and manipulation

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
