import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useTransactions } from "@/hooks/use-transactions";
import { Loader2 } from "lucide-react";
import { z } from "zod";
import { insertTransactionSchema } from "@shared/routes";

interface TransactionDialogProps {
  type: "entrada" | "saida";
  children: React.ReactNode;
}

export function TransactionDialog({ type, children }: TransactionDialogProps) {
  const [open, setOpen] = useState(false);
  const { createTransaction } = useTransactions();
  const [formData, setFormData] = useState({
    amount: "",
    description: "",
    category: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createTransaction.mutate({
      type,
      amount: parseFloat(formData.amount),
      description: formData.description,
      category: formData.category,
    }, {
      onSuccess: () => {
        setOpen(false);
        setFormData({ amount: "", description: "", category: "" });
      }
    });
  };

  const isIncome = type === "entrada";

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] p-6 rounded-2xl">
        <DialogHeader>
          <DialogTitle className={isIncome ? "text-green-600" : "text-red-600"}>
            {isIncome ? "Nova Entrada" : "Nova Saída"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="grid gap-6 py-4">
          <div className="grid gap-2">
            <Label htmlFor="amount">Valor (R$)</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              required
              placeholder="0,00"
              className="text-lg font-bold"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">Descrição</Label>
            <Input
              id="description"
              required
              placeholder={isIncome ? "Ex: Venda de peças" : "Ex: Conta de Luz"}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="category">Categoria</Label>
            <Select 
              value={formData.category} 
              onValueChange={(val) => setFormData({ ...formData, category: val })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione..." />
              </SelectTrigger>
              <SelectContent>
                {isIncome ? (
                  <>
                    <SelectItem value="Vendas">Vendas</SelectItem>
                    <SelectItem value="Serviços">Serviços</SelectItem>
                    <SelectItem value="Outros">Outros</SelectItem>
                  </>
                ) : (
                  <>
                    <SelectItem value="Fornecedores">Fornecedores</SelectItem>
                    <SelectItem value="Aluguel">Aluguel</SelectItem>
                    <SelectItem value="Funcionários">Funcionários</SelectItem>
                    <SelectItem value="Contas">Contas</SelectItem>
                    <SelectItem value="Outros">Outros</SelectItem>
                  </>
                )}
              </SelectContent>
            </Select>
          </div>
          <Button 
            type="submit" 
            disabled={createTransaction.isPending}
            className={`w-full h-12 text-lg font-semibold shadow-lg ${
              isIncome 
                ? "bg-green-600 hover:bg-green-700 shadow-green-200" 
                : "bg-red-600 hover:bg-red-700 shadow-red-200"
            }`}
          >
            {createTransaction.isPending ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              "Salvar"
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
