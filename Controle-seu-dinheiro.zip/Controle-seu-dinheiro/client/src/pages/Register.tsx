import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

import logoImg from "@assets/Screenshot_2026-01-12_22.47.01_1768268852616.png";

export default function Register() {
  const { registerMutation } = useAuth();
  const { toast } = useToast();
  const [loadingCnpj, setLoadingCnpj] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    cnpj: "",
    password: "",
    businessName: "",
    businessType: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validar telefone: ddd + 9 + 8 dígitos, total 11
    const rawPhone = formData.phone.replace(/\D/g, "");
    const allSame = /^(\d)\1+$/.test(rawPhone);
    
    if (rawPhone.length !== 11 || rawPhone[2] !== '9' || allSame) {
      toast({
        title: "Telefone inválido",
        description: "O número deve ter 11 dígitos, começar com 9 (ex: 119...) e não pode ter todos os números iguais.",
        variant: "destructive",
      });
      return;
    }

    registerMutation.mutate(formData);
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const formatPhone = (val: string) => {
    return val
      .replace(/\D/g, "")
      .substring(0, 11);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhone(e.target.value);
    handleChange("phone", formatted);
  };

  const formatCnpj = (val: string) => {
    return val
      .replace(/\D/g, "")
      .replace(/^(\d{2})(\d)/, "$1.$2")
      .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
      .replace(/\.(\d{3})(\d)/, ".$1/$2")
      .replace(/(\d{4})(\d)/, "$1-$2")
      .substring(0, 18);
  };

  const handleCnpjChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCnpj(e.target.value);
    handleChange("cnpj", formatted);
  };

  const lookupCnpj = async () => {
    const rawCnpj = formData.cnpj.replace(/\D/g, "");
    if (rawCnpj.length !== 14) {
      toast({
        title: "CNPJ Inválido",
        description: "Digite os 14 dígitos do CNPJ para buscar.",
        variant: "destructive",
      });
      return;
    }

    setLoadingCnpj(true);
    try {
      const response = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${rawCnpj}`);
      if (!response.ok) throw new Error("CNPJ não encontrado");
      const data = await response.json();
      
      setFormData(prev => ({
        ...prev,
        businessName: data.razao_social || data.nome_fantasia || prev.businessName,
      }));
      
      toast({
        title: "CNPJ Encontrado",
        description: `Negócio: ${data.razao_social}`,
      });
    } catch (error) {
      toast({
        title: "Erro na busca",
        description: "CNPJ não encontrado ou erro na API.",
        variant: "destructive",
      });
    } finally {
      setLoadingCnpj(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4 font-sans">
      <Card className="w-full max-w-lg border-none shadow-xl shadow-slate-200">
        <CardHeader className="space-y-2 text-center pb-8">
          <div className="flex justify-center mb-4">
            <img src={logoImg} alt="Dinheiro no Bolso" className="h-20 w-auto" />
          </div>
          <CardTitle className="text-2xl font-bold text-slate-900 text-balance">
            Em 1 minuto, você começa a controlar seu dinheiro de verdade.
          </CardTitle>
          <CardDescription className="text-slate-600">
            7 dias grátis para testar. Cancele quando quiser.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-xs font-bold text-slate-400 mb-6 uppercase tracking-widest text-center">
            Informações do Seu Negócio
          </div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Nome Completo</Label>
                <Input 
                  id="fullName" 
                  required 
                  value={formData.fullName}
                  onChange={e => handleChange("fullName", e.target.value)}
                  placeholder="Seu nome completo"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Celular com DDD</Label>
                <Input 
                  id="phone" 
                  required 
                  value={formData.phone}
                  onChange={handlePhoneChange}
                  placeholder="Ex: 11988887777"
                  maxLength={11}
                />
                <p className="text-[10px] text-slate-500">Use seu celular com DDD</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cnpj">CNPJ (Somente números)</Label>
              <div className="flex gap-2">
                <Input 
                  id="cnpj" 
                  required 
                  value={formData.cnpj}
                  onChange={handleCnpjChange}
                  placeholder="00.000.000/0000-00"
                  className="flex-1"
                />
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={lookupCnpj}
                  disabled={loadingCnpj}
                  className="shrink-0 px-4 flex items-center gap-2 border-primary text-primary hover:bg-primary/5"
                >
                  {loadingCnpj ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                  <span>Buscar</span>
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="businessName">Nome do Negócio</Label>
              <Input 
                id="businessName" 
                required 
                value={formData.businessName}
                onChange={e => handleChange("businessName", e.target.value)}
                placeholder="Ex: Mercearia do João"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="businessType">Tipo de Negócio</Label>
              <Select onValueChange={v => handleChange("businessType", v)}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mercado">Mercado / Mercearia</SelectItem>
                  <SelectItem value="Oficina">Oficina Mecânica</SelectItem>
                  <SelectItem value="Salao">Salão de Beleza / Barbearia</SelectItem>
                  <SelectItem value="Restaurante">Restaurante / Lanchonete</SelectItem>
                  <SelectItem value="Outro">Outro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">E-mail</Label>
              <Input 
                id="email" 
                type="email" 
                required 
                value={formData.email}
                onChange={e => handleChange("email", e.target.value)}
                placeholder="seu@email.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha</Label>
              <Input 
                id="password" 
                type="password" 
                required 
                value={formData.password}
                onChange={e => handleChange("password", e.target.value)}
                placeholder="Mínimo 6 caracteres"
              />
            </div>

            <div className="space-y-3 pt-2">
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="whatsapp" className="rounded border-slate-300" />
                <label htmlFor="whatsapp" className="text-xs text-slate-600">Aceito receber dicas por WhatsApp</label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="terms" required className="rounded border-slate-300" />
                <label htmlFor="terms" className="text-xs text-slate-600">Concordo com os Termos de Uso e Política de Privacidade</label>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-14 text-lg font-bold bg-primary hover:bg-primary/90 mt-6 shadow-xl shadow-primary/20 uppercase tracking-wide" 
              disabled={registerMutation.isPending}
            >
              {registerMutation.isPending ? <Loader2 className="animate-spin" /> : "🚀 Começar Agora Grátis"}
            </Button>
          </form>

          <div className="text-center mt-6 text-sm text-slate-500">
            Já tem uma conta?{" "}
            <Link href="/login" className="text-primary font-semibold hover:underline">
              Entrar agora
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
