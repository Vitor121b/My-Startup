import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, CheckCircle2, TrendingUp, ShieldCheck, Smartphone } from "lucide-react";
import { motion } from "framer-motion";

import logoImg from "@assets/Screenshot_2026-01-12_22.47.01_1768268852616.png";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background flex flex-col font-sans text-slate-900">
      {/* Navigation */}
      <nav className="w-full border-b bg-white/50 backdrop-blur-md fixed top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src={logoImg} alt="Dinheiro no Bolso" className="h-8 w-auto" />
            <span className="font-display font-bold text-xl text-slate-900 tracking-tight">
              Dinheiro no Bolso
            </span>
          </div>
          <div className="flex gap-4">
            <Link href="/login" className="text-sm font-medium text-slate-600 hover:text-primary transition-colors py-2">
              Entrar
            </Link>
            <Link href="/cadastro">
              <Button size="sm" className="hidden sm:flex bg-primary hover:bg-primary/90 text-white font-semibold shadow-lg shadow-primary/20">
                Começar Grátis
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 overflow-hidden">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center lg:text-left"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-600 text-sm font-semibold mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
              </span>
              Simples, Rápido e Eficiente
            </div>
            <h1 className="text-4xl lg:text-6xl font-display font-bold text-slate-900 leading-tight mb-6">
              Controle seu dinheiro sem <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-600">planilha nem papelada</span>.
            </h1>
            <p className="text-lg text-slate-600 mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Para donos de mercado, oficina e salão que querem saber todo dia se estão no lucro.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link href="/cadastro">
                <Button size="lg" className="w-full sm:w-auto h-14 px-8 text-lg bg-primary hover:bg-primary/90 text-white shadow-xl shadow-primary/25 hover:-translate-y-1 transition-all duration-200 uppercase font-bold tracking-wide">
                  🚀 COMEÇAR TESTE GRÁTIS - 7 DIAS
                </Button>
              </Link>
              <Link href="/login">
                <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 text-lg border-2 hover:bg-slate-50">
                  Já tenho conta
                </Button>
              </Link>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full blur-3xl opacity-50 z-0"></div>
            {/* Abstract UI Representation */}
            <div className="relative z-10 bg-white rounded-3xl shadow-2xl shadow-blue-900/10 border border-slate-100 p-6 max-w-md mx-auto transform rotate-[-2deg] hover:rotate-0 transition-transform duration-500">
              <div className="flex justify-between items-center mb-8">
                <div>
                  <div className="text-sm text-slate-500 font-medium">Saldo Atual</div>
                  <div className="text-3xl font-bold text-slate-900">R$ 12.450,00</div>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                  <TrendingUp className="w-6 h-6" />
                </div>
              </div>
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-blue-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${i === 2 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                        {i === 2 ? <TrendingUp className="w-5 h-5 rotate-180" /> : <TrendingUp className="w-5 h-5" />}
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">{i === 2 ? 'Fornecedor' : 'Venda #104'}</div>
                        <div className="text-xs text-slate-500">Hoje, 14:30</div>
                      </div>
                    </div>
                    <div className={`font-bold ${i === 2 ? 'text-red-600' : 'text-green-600'}`}>
                      {i === 2 ? '- R$ 450,00' : '+ R$ 120,00'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Tudo que você precisa</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Desenvolvido para pequenos empreendedores que querem crescer sem complicação.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { 
                icon: Smartphone, 
                title: "Use no celular ou computador", 
                desc: "Acesse na loja, em casa ou onde estiver. Interface otimizada para toque." 
              },
              { 
                icon: TrendingUp, 
                title: "Veja seu lucro de verdade", 
                desc: "Relatórios automáticos mostram se você está no azul ou vermelho. Gráficos simples." 
              },
              { 
                icon: ShieldCheck, 
                title: "Segurança de banco", 
                desc: "Seus dados criptografados. Backup automático. Conformidade com LGPD." 
              }
            ].map((feature, i) => (
              <div key={i} className="p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:shadow-lg hover:bg-blue-50/50 transition-all duration-300">
                <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center text-primary mb-6">
                  <feature.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Como Funciona Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-12">Como Funciona</h2>
          <div className="grid md:grid-cols-3 gap-8 relative">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto">1</div>
              <h3 className="text-xl font-bold">📝 Cadastre-se em 1 minuto</h3>
              <p className="text-slate-600">Nome, telefone e nome do seu negócio. Pronto.</p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto">2</div>
              <h3 className="text-xl font-bold">✅ Registre entradas e saídas</h3>
              <p className="text-slate-600">Aperta verde quando dinheiro ENTRA, vermelho quando SAI.</p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white text-xl font-bold mx-auto">3</div>
              <h3 className="text-xl font-bold">📈 Veja seu saldo crescer</h3>
              <p className="text-slate-600">Dashboard mostra seu progresso. Relatório mensal automático.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Depoimento Section */}
      <section className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <div className="text-5xl text-slate-200 mb-6 font-serif">"</div>
          <p className="text-2xl text-slate-700 italic mb-8">
            Como dono de mercado, eu perdia horas na planilha. Com o Dinheiro no Bolso, em 2 minutos eu sei como foi o dia. Foi essencial pra organizar minhas contas.
          </p>
          <div className="font-bold text-slate-900 text-lg">João Silva</div>
          <div className="text-slate-500 text-sm">Mercadinho São Paulo</div>
        </div>
      </section>

      {/* Planos Section (Otimizada) */}
      <section className="py-20 bg-slate-50" id="planos">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Planos Simples</h2>
          <p className="text-slate-600 mb-12">Escolha o melhor para o seu negócio</p>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="p-8 rounded-3xl border-none shadow-lg">
              <h3 className="text-xl font-bold mb-2">Teste Grátis</h3>
              <div className="text-3xl font-bold mb-4 text-slate-400">R$ 0,00</div>
              <p className="text-slate-500 mb-6 text-sm">7 dias completos para experimentar todas as funções.</p>
              <Link href="/cadastro">
                <Button variant="outline" className="w-full">Começar agora</Button>
              </Link>
            </Card>

            <Card className="p-8 rounded-3xl border-none shadow-lg">
              <h3 className="text-xl font-bold mb-2">Mensal</h3>
              <div className="text-3xl font-bold mb-4 text-slate-900">R$ 8,90</div>
              <p className="text-slate-500 mb-6 text-sm">Para quem quer testar e organizar mês a mês.</p>
              <Link href="/cadastro">
                <Button className="w-full bg-slate-900">Selecionar Plano</Button>
              </Link>
            </Card>

            <Card className="p-8 rounded-3xl border-2 border-primary shadow-xl relative">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-white text-xs font-bold px-3 py-1 rounded-full">
                ⭐ MAIS POPULAR
              </div>
              <h3 className="text-xl font-bold mb-2">Anual</h3>
              <div className="text-3xl font-bold mb-2 text-primary">R$ 59,90</div>
              <div className="text-green-600 text-sm font-bold mb-4">Economize 44%</div>
              <p className="text-slate-500 mb-6 text-sm">A escolha de quem quer controle total o ano todo.</p>
              <Link href="/cadastro">
                <Button className="w-full bg-primary hover:bg-primary/90">Selecionar Plano</Button>
              </Link>
            </Card>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-24 bg-primary text-white text-center">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-4">Pare de adivinhar seu lucro</h2>
          <p className="text-xl text-white/80 mb-12">Por R$ 0,30 por dia, tenha controle total do seu negócio.</p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Link href="/cadastro">
              <Button size="lg" className="w-full sm:w-auto h-16 px-10 text-xl bg-white text-primary hover:bg-slate-50 font-bold shadow-2xl">
                🎯 COMEÇAR TESTE GRÁTIS
              </Button>
            </Link>
            <a href="https://wa.me/5511999999999" target="_blank" rel="noopener noreferrer" className="text-white hover:underline flex items-center gap-2">
              <Smartphone className="w-5 h-5" /> 📞 Falar com nosso time
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t bg-slate-50 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Dinheiro no Bolso. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
