import { useAuth } from "@/hooks/use-auth";
import { useTransactions } from "@/hooks/use-transactions";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { TransactionDialog } from "@/components/TransactionDialog";
import { LogOut, Plus, Minus, TrendingUp, TrendingDown, Clock, Loader2, ArrowRight } from "lucide-react";
import { Link, useLocation } from "wouter";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

import { Badge } from "@/components/ui/badge";

import logoImg from "@assets/Screenshot_2026-01-12_22.47.01_1768268852616.png";

export default function Dashboard() {
  const { user, logoutMutation, isLoading: isLoadingAuth } = useAuth();
  const { transactions, stats, deleteTransaction, isLoading } = useTransactions();
  const [, setLocation] = useLocation();

  if (isLoadingAuth || isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    setLocation("/login");
    return null;
  }

  const formatMoney = (val: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  };

  const isTrialExpired = user.plan === 'free' && (stats?.daysRemaining || 0) <= 0;

  if (isTrialExpired) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center space-y-6 rounded-3xl border-none shadow-2xl">
          <div className="w-20 h-20 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto">
            <Clock className="w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-slate-900">Período de teste expirado</h1>
            <p className="text-slate-500">Seus 7 dias gratuitos acabaram. Assine um plano para continuar gerenciando seu negócio.</p>
          </div>
          <Link href="/planos">
            <Button className="w-full h-12 text-lg font-bold bg-primary hover:bg-primary/90">
              Ver Planos de Assinatura
            </Button>
          </Link>
          <Button variant="ghost" onClick={() => logoutMutation.mutate()} className="text-slate-400">
            Sair da conta
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans pb-20">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-30">
        <div className="max-w-3xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img src={logoImg} alt="Logo" className="h-8 w-auto" />
            <div>
              <h1 className="text-lg font-bold text-slate-900">Olá, {user.fullName.split(' ')[0]}!</h1>
              <p className="text-xs text-slate-500">{user.businessName}</p>
            </div>
            {user.isAdmin && (
              <Link href="/admin">
                <Button variant="outline" size="sm" className="ml-2">Admin</Button>
              </Link>
            )}
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => logoutMutation.mutate()}
            className="text-slate-400 hover:text-red-500"
          >
            <LogOut className="w-5 h-5" />
          </Button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6 space-y-6">
        
        {/* Trial / Plan Status */}
        <div className="bg-blue-600 rounded-2xl p-4 text-white shadow-lg shadow-blue-900/20 flex items-center justify-between">
          <div>
            <div className="text-xs font-medium text-blue-100 uppercase tracking-wider">Seu Plano</div>
            <div className="font-bold text-lg flex items-center gap-2">
              {user.plan === 'free' ? 'Período de Teste' : user.plan === 'monthly' ? 'Mensal' : 'Anual'}
              {user.plan === 'free' && (
                <Badge className="bg-white/20 text-white border-none text-[10px] py-0 h-5 uppercase">
                  🆓 TESTE GRÁTIS - {stats?.daysRemaining} dias restantes
                </Badge>
              )}
            </div>
          </div>
          {user.plan === 'free' && (
            <Link href="/planos">
              <Button size="sm" variant="secondary" className="text-blue-600 font-bold shadow-none hover:bg-white/90">
                Assinar Agora
              </Button>
            </Link>
          )}
        </div>

        {/* Balance Card */}
        <Card className="p-6 rounded-3xl border-none shadow-xl shadow-slate-200 bg-gradient-to-br from-primary/10 to-blue-500/10 overflow-hidden relative">
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-1">
              <h2 className="text-sm font-medium text-slate-500 uppercase tracking-wider">Seu Saldo</h2>
              <Badge className={((stats?.balance ?? 0) >= 0) ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}>
                {((stats?.balance ?? 0) >= 0) ? "✅ NO AZUL" : "⚠️ CUIDADO"}
              </Badge>
            </div>
            <div className={`text-4xl font-display font-bold mb-6 ${((stats?.balance ?? 0) >= 0) ? 'text-slate-900' : 'text-red-600'}`}>
              {formatMoney(stats?.balance ?? 0)}
            </div>
            <div className="text-xs text-slate-500 mb-4 font-medium">
              Este mês: <span className="text-green-600">+{formatMoney(stats?.income ?? 0)}</span> | <span className="text-red-600">-{formatMoney(stats?.expense ?? 0)}</span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/60 backdrop-blur-sm rounded-xl p-3 border border-white/40">
                <div className="flex items-center gap-2 text-green-700 text-xs font-bold mb-1 uppercase">
                  <TrendingUp className="w-4 h-4" /> Entradas
                </div>
                <div className="text-lg font-bold text-green-700">{formatMoney(stats?.income ?? 0)}</div>
              </div>
              <div className="bg-white/60 backdrop-blur-sm rounded-xl p-3 border border-white/40">
                <div className="flex items-center gap-2 text-red-700 text-xs font-bold mb-1 uppercase">
                  <TrendingDown className="w-4 h-4" /> Saídas
                </div>
                <div className="text-lg font-bold text-red-700">{formatMoney(stats?.expense ?? 0)}</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Dicas do Dia */}
        <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4 flex gap-3 items-start shadow-sm">
          <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center text-amber-600 shrink-0">
            <span className="text-lg">💡</span>
          </div>
          <div>
            <h4 className="text-sm font-bold text-amber-900">Dica do Dia</h4>
            <p className="text-xs text-amber-800">Registre toda venda no momento do pagamento para manter seu caixa sempre batendo!</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <TransactionDialog type="entrada">
            <Button className="h-16 text-lg font-bold bg-green-600 hover:bg-green-700 text-white shadow-lg shadow-green-200 rounded-xl flex flex-col items-center justify-center leading-none">
              <span className="flex items-center gap-2"><Plus className="w-6 h-6" /> DINHEIRO ENTROU</span>
              <span className="text-[10px] font-normal opacity-80 mt-1 uppercase tracking-tighter">Cliente pagou? Registre aqui</span>
            </Button>
          </TransactionDialog>
          
          <TransactionDialog type="saida">
            <Button className="h-16 text-lg font-bold bg-red-600 hover:bg-red-700 text-white shadow-lg shadow-red-200 rounded-xl flex flex-col items-center justify-center leading-none">
              <span className="flex items-center gap-2"><Minus className="w-6 h-6" /> DINHEIRO SAIU</span>
              <span className="text-[10px] font-normal opacity-80 mt-1 uppercase tracking-tighter">Pagou conta? Anote aqui</span>
            </Button>
          </TransactionDialog>
        </div>

        {/* Recent Transactions */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-800 text-lg">Histórico Recente</h3>
            {/* Could add a 'View All' link here later */}
          </div>

          {transactions && transactions.length > 0 ? (
            <div className="space-y-3">
              {transactions.map((t) => (
                <div key={t.id} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between group">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      t.type === 'entrada' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                    }`}>
                      {t.type === 'entrada' ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="font-bold text-slate-800">{t.description}</div>
                      <div className="text-xs text-slate-500">
                        {t.category} • {format(new Date(t.date || ""), "dd MMM, HH:mm", { locale: ptBR })}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`font-bold ${t.type === 'entrada' ? 'text-green-600' : 'text-red-600'}`}>
                      {t.type === 'entrada' ? '+' : '-'} {formatMoney(Number(t.amount))}
                    </div>
                    <button 
                      onClick={() => deleteTransaction.mutate(t.id)}
                      className="text-xs text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      Remover
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-3xl border border-slate-100 border-dashed">
              <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 mx-auto mb-3">
                <Clock className="w-6 h-6" />
              </div>
              <p className="text-slate-500 font-medium">Nenhuma movimentação ainda.</p>
              <p className="text-xs text-slate-400 mt-1">Registre sua primeira entrada ou saída.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
