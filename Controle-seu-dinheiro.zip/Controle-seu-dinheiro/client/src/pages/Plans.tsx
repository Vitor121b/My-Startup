import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Check, ArrowLeft, Star } from "lucide-react";

export default function Plans() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans p-4 pb-20 text-slate-900">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-2 mb-8">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Escolha seu Plano</h1>
        </div>

        <div className="mb-12 text-center">
          <p className="text-slate-600">Garantia de 30 dias ou seu dinheiro de volta. Cancele a qualquer momento.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Free Plan */}
          <Card className="rounded-3xl border-none shadow-lg p-2 flex flex-col h-full bg-white">
            <CardHeader className="text-center pt-6">
              <CardTitle className="text-xl">GRÁTIS</CardTitle>
              <CardDescription>7 dias completos</CardDescription>
              <div className="text-3xl font-bold mt-4">R$ 0,00</div>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-4">
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-500" /> Até 50 transações
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <span className="text-red-500">❌</span> Exportar dados
                </li>
                <li className="flex items-center gap-2 text-sm text-slate-500 italic">
                  Suporte por E-mail
                </li>
              </ul>
            </CardContent>
            <CardFooter className="pb-6">
              <Button variant="outline" className="w-full h-12 font-bold" disabled>Plano Atual</Button>
            </CardFooter>
          </Card>

          {/* Monthly Plan */}
          <Card className="rounded-3xl border-none shadow-lg p-2 flex flex-col h-full bg-white">
            <CardHeader className="text-center pt-6">
              <CardTitle className="text-xl">MENSAL</CardTitle>
              <CardDescription>Para quem quer testar</CardDescription>
              <div className="text-3xl font-bold mt-4 text-slate-900">R$ 8,90</div>
              <p className="text-xs text-slate-500 mt-1">/mês</p>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-4">
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-500" /> Transações ilimitadas
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-500" /> Exportar em PDF
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-500" /> Suporte via WhatsApp
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-500" /> Backup Manual
                </li>
              </ul>
            </CardContent>
            <CardFooter className="pb-6">
              <Link href={`/pagamento/confirmar?plano=mensal`} className="w-full">
                <Button className="w-full h-12 text-lg font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-xl">
                  Assinar Mensal
                </Button>
              </Link>
            </CardFooter>
          </Card>

          {/* Annual Plan (Featured) */}
          <Card className="rounded-3xl border-2 border-primary shadow-xl p-2 flex flex-col h-full bg-amber-50 relative overflow-visible scale-105 z-10">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-lg whitespace-nowrap">
              ⭐ MAIS POPULAR - ECONOMIZE 44%
            </div>
            <CardHeader className="text-center pt-8">
              <CardTitle className="text-xl flex items-center justify-center gap-2">
                ANUAL <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
              </CardTitle>
              <CardDescription>A escolha de 8 em cada 10 clientes</CardDescription>
              <div className="text-4xl font-bold mt-4 text-primary">R$ 59,90</div>
              <p className="text-xs text-slate-500 mt-1">/ano (R$ 4,99/mês)</p>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-4">
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-green-500" /> Transações ilimitadas
                </li>
                <li className="flex items-center gap-2 text-sm font-bold">
                  <Check className="w-4 h-4 text-green-500" /> PDF + Excel
                </li>
                <li className="flex items-center gap-2 text-sm font-bold">
                  <Check className="w-4 h-4 text-green-500" /> Suporte Prioritário 24h
                </li>
                <li className="flex items-center gap-2 text-sm font-bold">
                  <Check className="w-4 h-4 text-green-500" /> Backup Automático
                </li>
              </ul>
            </CardContent>
            <CardFooter className="pb-6">
              <Link href={`/pagamento/confirmar?plano=anual`} className="w-full">
                <Button className="w-full h-12 text-lg font-bold bg-primary hover:bg-primary/90 text-white rounded-xl shadow-lg shadow-primary/25">
                  Quero Economizar Agora
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
