import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

import logoImg from "@assets/Screenshot_2026-01-12_22.47.01_1768268852616.png";

export default function Login() {
  const { loginMutation } = useAuth();
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await loginMutation.mutateAsync(formData);
    } catch (err: any) {
      setError("Email ou senha incorretos. Por favor, tente novamente.");
      setFormData(prev => ({ ...prev, password: "" }));
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4 font-sans">
      <Card className="w-full max-w-md border-none shadow-xl shadow-slate-200">
        <CardHeader className="space-y-2 text-center pb-8">
          <div className="flex justify-center mb-4">
            <img src={logoImg} alt="Dinheiro no Bolso" className="h-20 w-auto" />
          </div>
          <CardTitle className="text-2xl font-bold text-slate-900">Acesse sua conta</CardTitle>
          <CardDescription>Gerencie seu negócio de qualquer lugar</CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">E-mail</Label>
              <Input 
                id="username" 
                type="email"
                required 
                value={formData.username}
                onChange={e => setFormData({...formData, username: e.target.value})}
                placeholder="seu@email.com"
                className="h-11"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha</Label>
              <Input 
                id="password" 
                type="password" 
                required 
                value={formData.password}
                onChange={e => setFormData({...formData, password: e.target.value})}
                placeholder="••••••••"
                className="h-11"
              />
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 text-lg font-semibold bg-primary hover:bg-primary/90 mt-4 shadow-lg shadow-primary/20" 
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? <Loader2 className="animate-spin" /> : "Entrar"}
            </Button>
          </form>

          <div className="text-center mt-6 text-sm text-slate-500">
            Ainda não tem conta?{" "}
            <Link href="/cadastro" className="text-primary font-semibold hover:underline">
              Começar grátis
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
