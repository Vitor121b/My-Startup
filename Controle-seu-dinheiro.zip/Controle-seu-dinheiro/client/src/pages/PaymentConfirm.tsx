import { useLocation, useSearch } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { ArrowLeft, CheckCircle, Loader2, ExternalLink } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function PaymentConfirm() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const plan = params.get("plano") || "mensal";
  const { toast } = useToast();
  
  const { data: links } = useQuery<{ monthly: string, annual: string }>({
    queryKey: ["/api/payment-links"],
  });

  const createPaymentRequest = useMutation({
    mutationFn: async (data: { plan: string, amount: string }) => {
      await apiRequest("POST", "/api/payment-requests", data);
    },
    onSuccess: () => {
      toast({ title: "Sucesso", description: "Sua solicitação foi enviada para aprovação." });
      setLocation("/dashboard");
    }
  });

  const isAnnual = plan === "anual";
  const amount = isAnnual ? "59.90" : "8.90";
  const paymentUrl = isAnnual ? links?.annual : links?.monthly;

  const handleConfirm = () => {
    createPaymentRequest.mutate({
      plan,
      amount
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans p-4 flex items-center justify-center">
      <Card className="w-full max-w-md rounded-3xl border-none shadow-xl">
        <CardHeader className="text-center pb-2">
          <div className="flex justify-start">
             <Button variant="ghost" size="icon" onClick={() => setLocation("/planos")} className="rounded-full -ml-2">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </div>
          <CardTitle className="text-2xl font-bold text-slate-900">Pagamento Seguro</CardTitle>
          <CardDescription>Finalize sua assinatura via PagBank</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 pt-4">
          <div className="bg-blue-50 p-4 rounded-xl text-center">
            <div className="text-sm text-blue-600 font-medium uppercase mb-1">
              Plano Selecionado: {isAnnual ? "ANUAL" : "MENSAL"}
            </div>
            <div className="text-3xl font-bold text-blue-900">
              R$ {amount.replace('.', ',')}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex gap-4 items-start">
              <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-600 shrink-0">1</div>
              <div>
                <p className="font-medium text-slate-900">Realize o pagamento</p>
                <p className="text-sm text-slate-500 mb-3">Clique abaixo para abrir o PagBank em outra aba.</p>
                <a href={paymentUrl} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="w-full mt-3 border-blue-200 text-blue-700 hover:bg-blue-50">
                    <ExternalLink className="w-4 h-4 mr-2" /> Pagar no PagBank
                  </Button>
                </a>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-600 shrink-0">2</div>
              <div>
                <p className="font-medium text-slate-900">Confirme aqui</p>
                <p className="text-sm text-slate-500">Após pagar, clique no botão abaixo para liberar seu acesso.</p>
              </div>
            </div>
          </div>

          <Button 
            onClick={handleConfirm}
            disabled={createPaymentRequest.isPending}
            className="w-full h-14 text-lg font-bold bg-green-600 hover:bg-green-700 text-white rounded-xl shadow-lg shadow-green-200 mt-4"
          >
            {createPaymentRequest.isPending ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : (
              <span className="flex items-center">
                <CheckCircle className="w-5 h-5 mr-2" /> Já Paguei
              </span>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
