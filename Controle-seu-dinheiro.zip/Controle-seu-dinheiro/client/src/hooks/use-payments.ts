import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertPaymentRequest, type PaymentRequest, type User } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

type AdminPaymentRequest = PaymentRequest & { user: User };

export function usePayments() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createPaymentRequest = useMutation({
    mutationFn: async (data: InsertPaymentRequest) => {
      const res = await fetch(api.payments.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) throw new Error("Failed to create payment request");
      return await res.json() as PaymentRequest;
    },
    onSuccess: () => {
      toast({
        title: "Pagamento informado!",
        description: "Vamos analisar e liberar seu plano em breve.",
      });
    },
  });

  return { createPaymentRequest };
}

export function useAdmin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: [api.admin.stats.path],
    queryFn: async () => {
      const res = await fetch(api.admin.stats.path);
      if (!res.ok) throw new Error("Failed to fetch admin stats");
      return await res.json() as { totalUsers: number; payingCustomers: number; monthlyRevenue: number };
    },
  });

  const { data: users, isLoading: isLoadingUsers } = useQuery({
    queryKey: [api.admin.users.path],
    queryFn: async () => {
      const res = await fetch(api.admin.users.path);
      if (!res.ok) throw new Error("Failed to fetch users");
      return await res.json() as User[];
    },
  });

  const { data: paymentRequests, isLoading: isLoadingRequests } = useQuery({
    queryKey: [api.payments.list.path],
    queryFn: async () => {
      const res = await fetch(api.payments.list.path);
      if (!res.ok) throw new Error("Failed to fetch requests");
      return await res.json() as AdminPaymentRequest[];
    },
  });

  const confirmPayment = useMutation({
    mutationFn: async (id: number) => {
      const url = api.payments.confirm.path.replace(":id", String(id));
      const res = await fetch(url, { method: "POST" });
      if (!res.ok) throw new Error("Failed to confirm");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.payments.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.admin.stats.path] });
      toast({ title: "Pagamento confirmado", variant: "default" });
    },
  });

  const rejectPayment = useMutation({
    mutationFn: async (id: number) => {
      const url = api.payments.reject.path.replace(":id", String(id));
      const res = await fetch(url, { method: "POST" });
      if (!res.ok) throw new Error("Failed to reject");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.payments.list.path] });
      toast({ title: "Pagamento rejeitado", variant: "destructive" });
    },
  });

  return {
    stats,
    users,
    paymentRequests,
    isLoadingStats,
    isLoadingUsers,
    isLoadingRequests,
    confirmPayment,
    rejectPayment,
  };
}
