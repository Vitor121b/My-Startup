import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertTransaction, type Transaction, type DashboardStats } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useTransactions() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: transactions, isLoading } = useQuery({
    queryKey: [api.transactions.list.path],
    queryFn: async () => {
      const res = await fetch(api.transactions.list.path);
      if (!res.ok) throw new Error("Failed to fetch transactions");
      return await res.json() as Transaction[];
    },
  });

  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: [api.transactions.stats.path],
    queryFn: async () => {
      const res = await fetch(api.transactions.stats.path);
      if (!res.ok) throw new Error("Failed to fetch stats");
      return await res.json() as DashboardStats;
    },
  });

  const createTransaction = useMutation({
    mutationFn: async (data: InsertTransaction) => {
      const res = await fetch(api.transactions.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create transaction");
      }
      return await res.json() as Transaction;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.transactions.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.transactions.stats.path] });
      toast({
        title: "Transação salva!",
        description: "Seu saldo foi atualizado.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteTransaction = useMutation({
    mutationFn: async (id: number) => {
      const url = api.transactions.delete.path.replace(":id", String(id));
      const res = await fetch(url, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.transactions.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.transactions.stats.path] });
      toast({
        title: "Removido",
        description: "A transação foi removida do histórico.",
      });
    },
  });

  return {
    transactions,
    stats,
    isLoading,
    isLoadingStats,
    createTransaction,
    deleteTransaction,
  };
}
