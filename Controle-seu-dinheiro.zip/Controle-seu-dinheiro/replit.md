# Dinheiro no Bolso

## Overview

"Dinheiro no Bolso" (Money in Your Pocket) is a financial control system designed for small Brazilian businesses such as markets, workshops, salons, and restaurants. The application helps business owners track income and expenses in a simple, intuitive way. It features a freemium model with 7 days free trial followed by paid subscription plans (monthly R$8.90 or annual R$59.90) processed through PagBank payment links.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state, local React state for UI
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **Animations**: Framer Motion for page transitions and micro-interactions
- **Build Tool**: Vite with React plugin

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **Authentication**: Passport.js with Local Strategy, session-based auth using express-session
- **Password Security**: Scrypt hashing with timing-safe comparison
- **API Design**: RESTful endpoints defined in shared routes contract (`shared/routes.ts`)

### Data Storage
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM with Zod schema validation (drizzle-zod)
- **Session Store**: connect-pg-simple for PostgreSQL session storage
- **Schema Location**: `shared/schema.ts` contains all table definitions

### Database Schema
- **users**: Stores user accounts with email, password, business info, CNPJ, plan status, trial dates
- **transactions**: Financial entries (entrada/saida) with amounts, descriptions, categories
- **paymentRequests**: Tracks subscription payment confirmations pending admin approval

### Authentication Flow
1. User registers with email, password, full name, phone, CNPJ, business name/type
2. 7-day free trial starts automatically
3. Session-based authentication with passport local strategy
4. Admin users have `isAdmin` flag for admin panel access

### Payment Integration
- External payment via PagBank links (no API integration)
- Users click payment link → pay on PagBank → return to app → confirm payment
- Admin manually approves payment requests to activate subscriptions

### Project Structure
```
client/           # React frontend
  src/
    components/   # Reusable UI components
    pages/        # Route pages (Landing, Login, Register, Dashboard, Plans, Admin)
    hooks/        # Custom React hooks (auth, transactions, payments)
    lib/          # Utilities and query client
server/           # Express backend
  auth.ts         # Passport authentication setup
  db.ts           # Database connection
  routes.ts       # API route handlers
  storage.ts      # Data access layer
shared/           # Shared code between client/server
  schema.ts       # Drizzle database schema
  routes.ts       # API contract definitions with Zod
```

## External Dependencies

### Payment Processing
- **PagBank**: External payment links for subscription processing
  - Annual plan: `https://pag.ae/81pu3vr64`
  - Monthly plan: `https://pag.ae/81pu4vWCK`

### Database
- **PostgreSQL**: Primary database (requires `DATABASE_URL` environment variable)

### Key NPM Packages
- **drizzle-orm / drizzle-kit**: Database ORM and migrations
- **@tanstack/react-query**: Server state management
- **passport / passport-local**: Authentication
- **express-session / connect-pg-simple**: Session management
- **zod / drizzle-zod**: Schema validation
- **shadcn/ui components**: Full suite of Radix-based UI primitives
- **framer-motion**: Animations
- **date-fns**: Date formatting (Portuguese BR locale)
- **recharts**: Dashboard charts

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Secret for session encryption (defaults to dev value if not set)