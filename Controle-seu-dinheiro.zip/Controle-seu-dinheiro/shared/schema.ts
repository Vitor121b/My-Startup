import { pgTable, text, serial, integer, boolean, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// === TABLE DEFINITIONS ===

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(), // Username/Email
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  cnpj: text("cnpj").notNull().unique(), // Added CNPJ field
  businessName: text("business_name").notNull(),
  businessType: text("business_type").notNull(), // Mercado, Oficina, Salão, Restaurante, Outro
  plan: text("plan").notNull().default("free"), // free, monthly, annual
  planStatus: text("plan_status").notNull().default("active"), // active, expired
  trialEndsAt: timestamp("trial_ends_at").notNull().defaultNow(),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // entrada, saida
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description").notNull(),
  category: text("category"),
  date: timestamp("date").defaultNow(),
});

export const paymentRequests = pgTable("payment_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  plan: text("plan").notNull(), // monthly, annual
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===

export const usersRelations = relations(users, ({ many }) => ({
  transactions: many(transactions),
  paymentRequests: many(paymentRequests),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
}));

export const paymentRequestsRelations = relations(paymentRequests, ({ one }) => ({
  user: one(users, {
    fields: [paymentRequests.userId],
    references: [users.id],
  }),
}));

// === BASE SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).extend({
  email: z.string().email("E-mail inválido"),
  phone: z.string().length(11, "Telefone deve ter 11 dígitos").regex(/^(\d{2})9/, "Telefone deve começar com o DDD seguido de 9"),
}).omit({ id: true, createdAt: true, isAdmin: true, trialEndsAt: true, plan: true, planStatus: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, userId: true, date: true });
export const insertPaymentRequestSchema = createInsertSchema(paymentRequests).omit({ id: true, userId: true, status: true, createdAt: true });

// === EXPLICIT API CONTRACT TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type PaymentRequest = typeof paymentRequests.$inferSelect;
export type InsertPaymentRequest = z.infer<typeof insertPaymentRequestSchema>;

// Request types
export type CreateUserRequest = InsertUser;
export type CreateTransactionRequest = InsertTransaction;
export type CreatePaymentRequestRequest = InsertPaymentRequest;

// Response types
export type UserResponse = User;
export type TransactionResponse = Transaction;
export type PaymentRequestResponse = PaymentRequest & { user?: User };

// Stats for Dashboard
export type DashboardStats = {
  balance: number;
  income: number;
  expense: number;
  recentTransactions: Transaction[];
  daysRemaining: number;
};
