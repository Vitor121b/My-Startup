import { z } from 'zod';
import { insertUserSchema, insertTransactionSchema, insertPaymentRequestSchema, users, transactions, paymentRequests } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  auth: {
    register: {
      method: 'POST' as const,
      path: '/api/register',
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    login: {
      method: 'POST' as const,
      path: '/api/login',
      input: z.object({
        username: z.string(),
        password: z.string(),
      }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/logout',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/user',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
  },
  transactions: {
    list: {
      method: 'GET' as const,
      path: '/api/transactions',
      responses: {
        200: z.array(z.custom<typeof transactions.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/transactions',
      input: insertTransactionSchema.extend({
        amount: z.coerce.number(), // Coerce from string/number
      }),
      responses: {
        201: z.custom<typeof transactions.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/transactions/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
    stats: {
      method: 'GET' as const,
      path: '/api/stats',
      responses: {
        200: z.object({
          balance: z.number(),
          income: z.number(),
          expense: z.number(),
          recentTransactions: z.array(z.custom<typeof transactions.$inferSelect>()),
          daysRemaining: z.number(),
        }),
      },
    }
  },
  payments: {
    create: {
      method: 'POST' as const,
      path: '/api/payment-requests',
      input: insertPaymentRequestSchema.extend({
         amount: z.coerce.number(),
      }),
      responses: {
        201: z.custom<typeof paymentRequests.$inferSelect>(),
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/admin/payment-requests',
      responses: {
        200: z.array(z.custom<typeof paymentRequests.$inferSelect & { user: typeof users.$inferSelect }>()),
      },
    },
    confirm: {
      method: 'POST' as const,
      path: '/api/admin/payment-requests/:id/confirm',
      responses: {
        200: z.custom<typeof paymentRequests.$inferSelect>(),
      },
    },
    reject: {
      method: 'POST' as const,
      path: '/api/admin/payment-requests/:id/reject',
      responses: {
        200: z.custom<typeof paymentRequests.$inferSelect>(),
      },
    }
  },
  admin: {
    stats: {
      method: 'GET' as const,
      path: '/api/admin/stats',
      responses: {
        200: z.object({
          totalUsers: z.number(),
          payingCustomers: z.number(),
          monthlyRevenue: z.number(),
        }),
      },
    },
    users: {
        method: 'GET' as const,
        path: '/api/admin/users',
        responses: {
            200: z.array(z.custom<typeof users.$inferSelect>()),
        }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
