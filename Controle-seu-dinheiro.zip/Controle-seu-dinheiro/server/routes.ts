import type { Express } from "express";
import type { Server } from "http";
import { setupAuth, hashPassword } from "./auth.js";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

async function seedDatabase() {
  const users = await storage.getAllUsers();
  if (users.length === 0) {
    const hashedPassword = await hashPassword("admin123");
    const admin = await storage.createUser({
      email: "admin@dinheironobolso.com",
      password: hashedPassword,
      fullName: "Administrador",
      phone: "11999999999",
      cnpj: "00000000000191", // Dummy CNPJ for admin
      businessName: "Dinheiro no Bolso HQ",
      businessType: "Outro",
    });
    
    await storage.createTransaction({
      userId: admin.id,
      type: "entrada",
      amount: "1500.00",
      description: "Vendas do dia",
      category: "Vendas"
    });
    
    await storage.createTransaction({
      userId: admin.id,
      type: "saida",
      amount: "300.00",
      description: "Fornecedor de bebidas",
      category: "Fornecedores"
    });
    
    console.log("Database seeded with admin user");
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  setupAuth(app);
  seedDatabase();

  app.get("/api/transactions", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const txs = await storage.getTransactions((req.user as any).id);
    res.json(txs);
  });

  app.post("/api/transactions", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const txSchema = z.object({
        type: z.string(),
        amount: z.union([z.string(), z.number()]),
        description: z.string(),
        category: z.string().optional()
      });
      const input = txSchema.parse(req.body);
      const tx = await storage.createTransaction({ 
        ...input, 
        amount: input.amount.toString(),
        userId: (req.user as any).id 
      });
      res.status(201).json(tx);
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.delete("/api/transactions/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    await storage.deleteTransaction(parseInt(req.params.id), (req.user as any).id);
    res.sendStatus(204);
  });

  app.get("/api/transactions/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const stats = await storage.getDashboardStats((req.user as any).id);
    res.json(stats);
  });

  const requireAdmin = (req: any, res: any, next: any) => {
      if (!req.isAuthenticated() || !req.user.isAdmin) {
          return res.status(403).json({ message: "Forbidden" });
      }
      next();
  };

  app.get("/api/admin/stats", requireAdmin, async (req, res) => {
      const stats = await storage.getStats();
      res.json(stats);
  });

  app.get("/api/admin/users", requireAdmin, async (req, res) => {
      const users = await storage.getAllUsers();
      res.json(users);
  });

  app.patch("/api/payment-requests/:id/status", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = z.object({ status: z.string() }).parse(req.body);
      const updated = await storage.updatePaymentRequestStatus(id, status);
      res.json(updated);
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.post("/api/payment-requests", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const { plan, amount } = z.object({ plan: z.string(), amount: z.string() }).parse(req.body);
      const request = await storage.createPaymentRequest({
        plan,
        amount,
        userId: (req.user as any).id,
      });
      res.status(201).json(request);
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.get("/api/payment-requests", requireAdmin, async (req, res) => {
    const requests = await storage.getPaymentRequests();
    res.json(requests);
  });

  app.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) return res.status(500).json({ message: "Logout failed" });
      res.sendStatus(200);
    });
  });

  app.get("/api/payment-links", (req, res) => {
    res.json({
      monthly: "https://pag.ae/81pu4vWCK",
      annual: "https://pag.ae/81pu3vr64"
    });
  });

  return httpServer;
}
