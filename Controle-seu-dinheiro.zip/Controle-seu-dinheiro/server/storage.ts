import { db } from "./db";
import {
  users, transactions, paymentRequests,
  type User, type InsertUser,
  type Transaction, type InsertTransaction,
  type PaymentRequest, type InsertPaymentRequest,
  type DashboardStats
} from "@shared/schema";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPlan(id: number, plan: string, status: string): Promise<User>;
  getAllUsers(): Promise<User[]>;
  getStats(): Promise<{ totalUsers: number, payingCustomers: number, monthlyRevenue: number }>;

  // Transactions
  getTransactions(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction & { userId: number }): Promise<Transaction>;
  deleteTransaction(id: number, userId: number): Promise<void>;
  getDashboardStats(userId: number): Promise<DashboardStats>;

  // Payments
  createPaymentRequest(request: InsertPaymentRequest & { userId: number }): Promise<PaymentRequest>;
  getPaymentRequests(): Promise<(PaymentRequest & { user: User })[]>;
  updatePaymentRequestStatus(id: number, status: string): Promise<PaymentRequest>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const trialEnds = new Date();
    trialEnds.setDate(trialEnds.getDate() + 7);

    const [user] = await db.insert(users).values({
      ...insertUser,
      trialEndsAt: trialEnds,
      plan: 'free',
      planStatus: 'active',
      isAdmin: insertUser.email === 'admin@dinheironobolso.com' // Simple admin check for demo
    }).returning();
    return user;
  }

  async updateUserPlan(id: number, plan: string, status: string): Promise<User> {
    const [user] = await db.update(users)
      .set({ plan, planStatus: status })
      .where(eq(users.id, id))
      .returning();
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
      return await db.select().from(users);
  }

  async getStats(): Promise<{ totalUsers: number, payingCustomers: number, monthlyRevenue: number }> {
      const allUsers = await db.select().from(users);
      const paying = allUsers.filter(u => u.plan !== 'free' && u.planStatus === 'active');
      
      // Calculate revenue (rough estimate based on active plans)
      const revenue = paying.reduce((acc, user) => {
          return acc + (user.plan === 'monthly' ? 8.90 : (59.90 / 12));
      }, 0);

      return {
          totalUsers: allUsers.length,
          payingCustomers: paying.length,
          monthlyRevenue: Math.round(revenue * 100) / 100
      };
  }

  // Transactions
  async getTransactions(userId: number): Promise<Transaction[]> {
    return await db.select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.date));
  }

  async createTransaction(transaction: InsertTransaction & { userId: number }): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions).values({
      ...transaction,
      date: new Date()
    }).returning();
    return newTransaction;
  }

  async deleteTransaction(id: number, userId: number): Promise<void> {
    await db.delete(transactions)
      .where(and(eq(transactions.id, id), eq(transactions.userId, userId)));
  }

  async getDashboardStats(userId: number): Promise<DashboardStats> {
    const txs = await this.getTransactions(userId);
    
    let income = 0;
    let expense = 0;

    txs.forEach(t => {
      const val = parseFloat(t.amount.toString());
      if (t.type === 'entrada') income += val;
      else expense += val;
    });

    const user = await this.getUser(userId);
    const now = new Date();
    const trialEnds = new Date(user!.trialEndsAt || now);
    const daysRemaining = Math.ceil((trialEnds.getTime() - now.getTime()) / (1000 * 3600 * 24));

    return {
      balance: income - expense,
      income,
      expense,
      recentTransactions: txs.slice(0, 5),
      daysRemaining: Math.max(0, daysRemaining),
    };
  }

  // Payments
  async createPaymentRequest(request: InsertPaymentRequest & { userId: number }): Promise<PaymentRequest> {
    const [req] = await db.insert(paymentRequests).values(request).returning();
    return req;
  }

  async getPaymentRequests(): Promise<(PaymentRequest & { user: User })[]> {
    // Join manually since drizzle relations are for query builder mostly
    const reqs = await db.select().from(paymentRequests).orderBy(desc(paymentRequests.createdAt));
    const results = [];
    for (const req of reqs) {
        const user = await this.getUser(req.userId);
        if (user) {
            results.push({ ...req, user });
        }
    }
    return results;
  }

  async updatePaymentRequestStatus(id: number, status: string): Promise<PaymentRequest> {
    const [req] = await db.update(paymentRequests)
      .set({ status })
      .where(eq(paymentRequests.id, id))
      .returning();
      
    // If approved, update user plan
    if (status === 'approved' && req) {
        await this.updateUserPlan(req.userId, req.plan, 'active');
    }
    
    return req;
  }
}

export const storage = new DatabaseStorage();
